import './App.css';
import Timer from './components/Timer';

function App() {
  return (
    <Timer id="timerTable"/>
  );
}

export default App;
