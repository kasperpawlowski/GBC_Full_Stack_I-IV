const calculator = require('./calculator');

const a = 6;
const b = 6;
const c = 4;

console.log(`multiply ${a} * ${b} equals: ${calculator.multiplyTwoNumbers(a, b)}`);
console.log(`even doubler ${c} equals: ${calculator.evenDoubler(c)}`);