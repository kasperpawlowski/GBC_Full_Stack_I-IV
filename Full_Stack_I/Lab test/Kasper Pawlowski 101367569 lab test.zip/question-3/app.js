const progressBar = require('./progress-bar');

// CALL TO CHECK IF STAGE 1 WORKS
progressBar.startProgress();

// CALL TO CHECK IF STAGE 2 WORKS AS WELL
//progressBar.startProgress_();